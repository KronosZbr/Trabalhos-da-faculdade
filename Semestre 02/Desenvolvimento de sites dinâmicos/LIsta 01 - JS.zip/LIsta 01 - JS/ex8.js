var din=Number(window.prompt('digite o valor em dolar: '));
var con;
function dolar(con) {  
con = din*5
return(con)   
}
alert(dolar(con))