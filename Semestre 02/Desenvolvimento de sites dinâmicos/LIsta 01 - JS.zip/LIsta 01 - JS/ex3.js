var a = window.prompt('digite o número 1');
var b = window.prompt('digite o número 2');
function calcular(V1,V2){
return Number(V1) + Number(V2);
}

alert(calcular(a,b));