var a = window.prompt('digite o número 1');
function calcular(V1,V2){
return Number(V1)*2;
}

alert(calcular(a));