var b;
function nome(b){
b = window.prompt("digite seu nome: ");
return b;
}
alert ("Bem vindo " + nome(b));
