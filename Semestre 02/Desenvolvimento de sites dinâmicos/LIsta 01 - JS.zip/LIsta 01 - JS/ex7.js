var r=Number(window.prompt('digite o número do raio do circulo'));
var pi=(Number(3.14));
var total = 2*pi*r;
console.info("A area é igual a: "+total + "%o","https://pt.wikihow.com/Calcular-o-Raio-de-um-C%C3%ADrculo")
