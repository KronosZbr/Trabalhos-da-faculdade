var a;
function alerta(a){
a = alert("Boas vindas");
return a;
}

alerta(a);