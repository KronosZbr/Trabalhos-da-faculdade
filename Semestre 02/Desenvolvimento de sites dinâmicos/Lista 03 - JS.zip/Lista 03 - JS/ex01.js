function nomes(nome, idade) {
    return `Olá, meu nome é ${nome} e eu tenho ${idade} anos.`;
}

const nome = "João";
const idade = 18;
const mensagem = nomes(nome, idade);
console.log(mensagem);