var pessoa = {
    nome: "Robson",
    idade:28,
    profissao:"uber",
}
console.dir(pessoa)
console.log("O nome da pessoa é: "+ pessoa.nome)