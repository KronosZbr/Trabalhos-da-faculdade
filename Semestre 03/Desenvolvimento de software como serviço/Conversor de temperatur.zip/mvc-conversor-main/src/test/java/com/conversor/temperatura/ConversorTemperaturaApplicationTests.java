package com.conversor.temperatura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConversorTemperaturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
